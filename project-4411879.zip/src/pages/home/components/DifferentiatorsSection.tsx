import { useState } from 'react';

export default function DifferentiatorsSection() {
  const [imageLoaded, setImageLoaded] = useState(false);

  const features = [
    {
      icon: 'ri-settings-3-line',
      text: 'Hybrid drive-train (gearbox + medium speed PMG) for superior performance'
    },
    {
      icon: 'ri-global-line',
      text: 'Proven technology with global installations in Australia, South Africa, Brazil and the Middle East'
    },
    {
      icon: 'ri-time-line',
      text: 'Rapid delivery'
    },
    {
      icon: 'ri-money-dollar-circle-line',
      text: 'Reduced Opex costs due to PMG and hybrid drive-train'
    },
    {
      icon: 'ri-hand-coin-line',
      text: 'Lower BOP costs with larger WTG sizes, achieving 20-25% savings'
    },
    {
      icon: 'ri-leaf-line',
      text: 'Decreased LCOE through technological efficiency and BOP savings'
    }
  ];

  return (
    <section className="bg-white py-20 lg:py-32">
      <div className="max-w-7xl mx-auto px-6 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Image */}
          <div className="order-2 lg:order-1 relative" data-aos="fade-right" data-aos-duration="1200">
            {!imageLoaded && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-16 h-16 border-4 border-[#8DC63F] border-t-transparent rounded-full animate-spin"></div>
              </div>
            )}
            <img 
              src="https://venwindrefex.com/wp-content/uploads/2025/01/home-image.jpg" 
              alt="Wind Turbine" 
              className={`w-full h-auto object-cover transition-opacity duration-500 ${imageLoaded ? 'opacity-100' : 'opacity-0'}`}
              onLoad={() => setImageLoaded(true)}
            />
          </div>

          {/* Content */}
          <div className="order-1 lg:order-2">
            <h2 className="text-gray-900 text-4xl lg:text-5xl font-bold mb-6" data-aos="fade-left" data-aos-duration="1000">
              Our differentiators
            </h2>
            <p className="text-gray-700 text-lg mb-8 leading-relaxed" data-aos="fade-left" data-aos-delay="100" data-aos-duration="1000">
              Offering wind turbines with advanced German technology from Vensys Energy AG at competitive prices.
            </p>

            <div className="space-y-6">
              {features.map((feature, index) => (
                <div 
                  key={index} 
                  className="flex items-start space-x-4"
                  data-aos="fade-left"
                  data-aos-delay={150 + (index * 50)}
                  data-aos-duration="800"
                >
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-[#8DC63F]/10 hover:bg-gray-900 flex items-center justify-center transition-all duration-300 group cursor-pointer">
                    <i className={`${feature.icon} text-[#8DC63F] group-hover:text-white text-xl transition-colors duration-300`}></i>
                  </div>
                  <p className="text-gray-700 text-base leading-relaxed pt-2">
                    {feature.text}
                  </p>
                </div>
              ))}
            </div>

            <div className="mt-10" data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
              <a 
                href="/technology" 
                className="inline-block bg-[#8DC63F] hover:bg-[#7AB62F] text-white text-lg font-bold px-10 py-4 transition-all duration-300 cursor-pointer whitespace-nowrap"
              >
                Discover Our Technology
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}