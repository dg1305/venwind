
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import AOS from 'aos';
import 'aos/dist/aos.css';

interface HeroContent {
  title: string;
  subtitle: string;
  buttonText: string;
  buttonLink: string;
  videoUrl: string;
}

export default function HeroSection() {
  const [heroContent, setHeroContent] = useState<HeroContent>({
    title: 'Revolutionizing Wind Energy',
    subtitle: 'Explore the power of cutting-edge wind turbine manufacturing technology in partnership with Vensys Energy AG, Germany',
    buttonText: 'Learn More',
    buttonLink: '/products',
    videoUrl: 'https://venwindrefex.com/wp-content/uploads/2025/01/5097121_Aerial-View_Alternative_1920x1080-1.mp4'
  });

  useEffect(() => {
    AOS.init({
      duration: 1000,
      once: true,
    });

    const savedContent = localStorage.getItem('heroContent');
    if (savedContent) {
      try {
        setHeroContent(JSON.parse(savedContent));
      } catch (error) {
        console.error('Error loading hero content:', error);
      }
    }
  }, []);

  return (
    <section className="relative h-screen w-full overflow-hidden">
      {/* Background Video */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover"
      >
        <source src={heroContent.videoUrl} type="video/mp4" />
      </video>

      {/* Dark Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/40 to-black/50"></div>

      {/* Content */}
      <div className="relative h-full flex items-end pb-32 px-6 md:px-12 lg:px-20">
        <div className="max-w-6xl">
          <h1 
            className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight"
            data-aos="fade-right"
          >
            {heroContent.title}
          </h1>
          <p 
            className="text-lg md:text-xl text-white/90 mb-8 whitespace-nowrap"
            data-aos="fade-right"
            data-aos-delay="200"
          >
            {heroContent.subtitle}
          </p>
          <Link
            to={heroContent.buttonLink}
            className="inline-block bg-[#8DC63F] hover:bg-[#7AB62F] text-white font-bold px-8 py-4 rounded-md transition-all duration-300 whitespace-nowrap"
            data-aos="fade-right"
            data-aos-delay="400"
          >
            {heroContent.buttonText}
          </Link>
        </div>
      </div>
    </section>
  );
}
