export default function Footer() {
  return (
    <footer className="bg-[#0D1D27] text-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-16 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Logo */}
          <div data-aos="fade-up" data-aos-delay="0">
            <img 
              src="https://venwindrefex.com/wp-content/uploads/2023/11/Venwind_Logo_Final-white.png" 
              alt="Venwind Refex" 
              className="h-12 w-auto mb-6"
            />
          </div>

          {/* Corporate Office */}
          <div data-aos="fade-up" data-aos-delay="100">
            <h6 className="text-white text-lg font-bold mb-6">Corporate Office</h6>
            <p className="text-gray-300 text-sm leading-relaxed mb-4">
              <strong>Venwind Refex Power Limited</strong><br />
              6<sup>th</sup> Floor, Refex Towers, Sterling Road Signal,<br />
              313, Valluvar Kottam High Road,<br />
              Nungambakkam, Chennai – 600034, Tamil Nadu
            </p>
            <a 
              href="mailto:contact@venwindrefex.com" 
              className="text-gray-300 text-sm hover:text-[#8DC63F] transition-colors"
            >
              contact@venwindrefex.com
            </a>
            <h6 className="text-white text-lg font-bold mt-6">
              <a 
                href="tel:+91(44)69908410" 
                className="hover:text-[#8DC63F] transition-colors"
              >
                +91 (44) 69908410
              </a>
            </h6>
          </div>

          {/* Links */}
          <div>
            <h6 className="text-white text-lg font-bold mb-6">Links</h6>
            <ul className="space-y-3">
              <li>
                <a
                  href="/"
                  className="text-gray-300 text-sm hover:text-[#8DC63F] transition-colors"
                >
                  Home
                </a>
              </li>
              <li>
                <a
                  href="/about-us"
                  className="text-gray-300 text-sm hover:text-[#8DC63F] transition-colors"
                >
                  About Us
                </a>
              </li>
              <li>
                <a
                  href="/products"
                  className="text-gray-300 text-sm hover:text-[#8DC63F] transition-colors"
                >
                  Products
                </a>
              </li>
              <li>
                <a
                  href="/technology"
                  className="text-gray-300 text-sm hover:text-[#8DC63F] transition-colors"
                >
                  Technology
                </a>
              </li>
              <li>
                <a
                  href="/sustainability"
                  className="text-gray-300 text-sm hover:text-[#8DC63F] transition-colors"
                >
                  Sustainability
                </a>
              </li>
              <li>
                <a
                  href="/careers"
                  className="text-gray-300 text-sm hover:text-[#8DC63F] transition-colors"
                >
                  Careers
                </a>
              </li>
            </ul>
          </div>

          {/* Social Media */}
          <div data-aos="fade-up" data-aos-delay="300">
            <h6 className="text-white text-lg font-bold mb-6">Social Media</h6>
            <div className="flex items-center space-x-4 mb-6">
              <a 
                href="https://www.facebook.com/refexindustrieslimited/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-gray-800 hover:bg-[#8DC63F] flex items-center justify-center transition-colors cursor-pointer"
              >
                <i className="ri-facebook-fill text-white text-lg"></i>
              </a>
              <a 
                href="https://x.com/GroupRefex" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-gray-800 hover:bg-[#8DC63F] flex items-center justify-center transition-colors cursor-pointer"
              >
                <i className="ri-twitter-x-fill text-white text-lg"></i>
              </a>
              <a 
                href="https://www.linkedin.com/company/refex-group/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-gray-800 hover:bg-[#8DC63F] flex items-center justify-center transition-colors cursor-pointer"
              >
                <i className="ri-linkedin-fill text-white text-lg"></i>
              </a>
              <a 
                href="https://www.instagram.com/refexgroup/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-gray-800 hover:bg-[#8DC63F] flex items-center justify-center transition-colors cursor-pointer"
              >
                <i className="ri-instagram-fill text-white text-lg"></i>
              </a>
              <a 
                href="https://www.youtube.com/@refexgroup" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-gray-800 hover:bg-[#8DC63F] flex items-center justify-center transition-colors cursor-pointer"
              >
                <i className="ri-youtube-fill text-white text-lg"></i>
              </a>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed">
              To know more about Refex<br />
              click here - <a 
                href="https://www.refex.group/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="font-bold hover:text-[#8DC63F] transition-colors"
              >
                www.refex.group
              </a>
            </p>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-6 lg:px-16 py-6">
          <p className="text-gray-400 text-sm text-center">
            <a href="/" className="hover:text-[#8DC63F] transition-colors">Venwind Refex Power Limited</a> © 2025. All Rights Reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}