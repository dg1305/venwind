export default function GallerySection() {
  const images = [
    'https://venwindrefex.com/wp-content/uploads/2025/01/gallery-img01.jpg',
    'https://venwindrefex.com/wp-content/uploads/2025/01/gallery-img04.jpg',
    'https://venwindrefex.com/wp-content/uploads/2025/01/gallery-img02.jpg',
    'https://venwindrefex.com/wp-content/uploads/2025/01/gallery-img05.jpg',
  ];

  return (
    <section className="py-0 bg-gray-900">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-0">
        {images.map((image, index) => (
          <div 
            key={index} 
            className="relative overflow-hidden group cursor-pointer h-80"
          >
            <img 
              src={image} 
              alt={`Gallery ${index + 1}`}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </div>
        ))}
      </div>
    </section>
  );
}
