export default function BrochureSection() {
  return (
    <section className="py-16 bg-[#8DC63F]">
      <div className="max-w-7xl mx-auto px-6 lg:px-16">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          <h2 className="text-white text-3xl lg:text-4xl font-bold">
            Download Our Product Brochure!
          </h2>
          
          <a 
            href="https://venwindrefex.com/wp-content/uploads/2025/02/Brochure_Venwind.pdf"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-white hover:bg-gray-100 text-gray-900 text-lg font-bold px-10 py-4 transition-all duration-300 cursor-pointer whitespace-nowrap"
          >
            Download
          </a>
        </div>
      </div>
    </section>
  );
}
