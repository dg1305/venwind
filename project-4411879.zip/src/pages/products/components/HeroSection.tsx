export default function HeroSection() {
  return (
    <>
      {/* Header Div */}
      <div className="h-24 bg-white"></div>
      
      {/* Products Section with Wind Turbine Background */}
      <section 
        className="relative h-[500px] w-full overflow-hidden bg-cover bg-center"
        style={{
          backgroundImage: 'url(https://readdy.ai/api/search-image?query=Modern%20wind%20turbines%20farm%20against%20clear%20blue%20sky%2C%20renewable%20energy%20infrastructure%2C%20clean%20technology%2C%20sustainable%20power%20generation%2C%20white%20wind%20turbines%20with%20three%20blades%20rotating%2C%20green%20energy%20landscape%2C%20environmental%20conservation%2C%20industrial%20wind%20power%20installation%2C%20bright%20daylight%20scene%20with%20minimal%20clouds&width=1920&height=500&seq=products-hero-bg&orientation=landscape)',
        }}
      >
        <div className="absolute inset-0 bg-black/40"></div>
        <div className="relative z-10 h-full flex items-center justify-center">
          <h1 className="text-white text-6xl font-bold">Products</h1>
        </div>
      </section>
    </>
  );
}
