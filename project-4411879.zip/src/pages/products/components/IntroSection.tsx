export default function IntroSection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-16">
        <h2 className="text-gray-900 text-4xl lg:text-5xl font-bold text-center mb-16" data-aos="fade-up">
          State-of-the-Art Wind Turbine Solutions
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-20">
          <div className="text-gray-700 text-base leading-relaxed" data-aos="fade-up">
            Our flagship GWH182-5.3 MW wind turbine features advanced engineering for exceptional performance in low wind areas.
          </div>
          
          <div className="text-gray-700 text-base leading-relaxed" data-aos="fade-up">
            The GWH182-5.3 MW combines efficiency, adaptability, and reliability, marking a breakthrough in wind power technology.
          </div>
          
          <div className="text-gray-700 text-base leading-relaxed" data-aos="fade-up">
            Designed for India's diverse wind conditions, the GWH182-5.3 MW maximizes energy capture with its 182m rotor diameter and 130m hub height.
          </div>
        </div>
      </div>
    </section>
  );
}
