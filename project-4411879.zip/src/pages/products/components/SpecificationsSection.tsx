export default function SpecificationsSection() {
  const specs = [
    { value: '5.3 MW', label: 'Rated Capacity' },
    { value: '183.4m', label: 'Rotor Diameter' },
    { value: '26417 m<sup>2</sup>', label: 'Swept Area' },
    { value: '130m', label: 'Hub Height' },
    { value: '2.5 m/s', label: 'Cut-in Wind Speed' },
    { value: 'IEC S', label: 'Class' },
  ];

  return (
    <section className="py-20 bg-white relative">
      <div className="absolute right-0 top-20 w-1/3 opacity-10 hidden lg:block">
        <img 
          src="https://venwindrefex.com/wp-content/uploads/2023/12/texture-back-10.png" 
          alt="" 
          className="w-full h-auto"
        />
      </div>
      
      <div className="max-w-7xl mx-auto px-6 lg:px-16 relative z-10">
        <h2 className="text-gray-900 text-4xl lg:text-5xl font-bold text-center mb-20" data-aos="fade-up">
          Technical Specifications
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {specs.slice(0, 3).map((spec, index) => (
            <div 
              key={index} 
              className="text-center"
              data-aos="fade-up"
            >
              <h2 className="text-gray-900 text-6xl font-bold mb-4" dangerouslySetInnerHTML={{ __html: spec.value }}></h2>
              <div className="w-24 h-1 bg-[#8DC63F] mx-auto mb-4"></div>
              <h5 className="text-gray-700 text-lg font-semibold">{spec.label}</h5>
            </div>
          ))}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {specs.slice(3).map((spec, index) => (
            <div 
              key={index} 
              className="text-center"
              data-aos="fade-up"
            >
              <h2 className="text-gray-900 text-6xl font-bold mb-4">{spec.value}</h2>
              <div className="w-24 h-1 bg-[#8DC63F] mx-auto mb-4"></div>
              <h5 className="text-gray-700 text-lg font-semibold">{spec.label}</h5>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}