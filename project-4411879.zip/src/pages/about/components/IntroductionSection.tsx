export default function IntroductionSection() {
  return (
    <section className="py-20 bg-[#f8f9fa]">
      <div className="max-w-7xl mx-auto px-6 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div data-aos="fade-left">
            <p className="text-sm font-semibold text-gray-600 uppercase tracking-wider mb-4">
              Introduction
            </p>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 leading-tight">
              Pioneering the Future of Renewable Energy
            </h2>
            <p className="text-gray-700 text-base leading-relaxed mb-6">
              Venwind Refex, a partnership between Refex and Venwind, aims to transform wind energy in India through innovation and sustainability, delivering advanced turbine technology and manufacturing excellence.
            </p>
            <p className="text-gray-700 text-base leading-relaxed">
              Venwind Refex strives to be a leading wind turbine OEM in India, combining global expertise with local insight. Our advanced facility is set to produce 5.3 MW turbines, aiming for a 5 GW annual capacity within five years.
            </p>
          </div>

          {/* Right Image */}
          <div data-aos="fade-up" className="flex justify-center">
            <div className="relative w-full max-w-[630px]">
              <div className="aspect-square rounded-full overflow-hidden shadow-xl">
                <img 
                  src="https://venwindrefex.com/wp-content/uploads/2025/01/about-usbg-630x630.jpg"
                  alt="Driving Our Renewable Future"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute top-1/4 right-8 bg-white/95 backdrop-blur-sm rounded-full px-10 py-8 shadow-2xl">
                <p className="text-center text-gray-900 font-bold text-lg leading-snug">
                  Driving Our<br />Renewable Future
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
