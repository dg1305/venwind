export default function HeroSection() {
  return (
    <section 
      className="relative h-[350px] flex items-center justify-center bg-cover bg-center mt-20"
      style={{
        backgroundImage: 'url(https://venwindrefex.com/wp-content/uploads/2025/01/about-us-banner.jpg)',
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-b from-gray-900/60 via-gray-900/50 to-gray-900/60"></div>
      <div className="relative z-10 text-center px-4">
        <h1 className="text-5xl md:text-6xl font-bold text-white tracking-wide">About Us</h1>
      </div>
    </section>
  );
}
