export default function FutureGoalsSection() {
  return (
    <section 
      className="relative bg-cover bg-center py-32 lg:py-40"
      style={{
        backgroundImage: 'url(https://static.readdy.ai/image/d0ead66ce635a168f1e83b108be94826/1068d46b1e389bbe3b4192e16de71e05.png)'
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/20 to-black/30"></div>
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-16">
        <div className="max-w-2xl" data-aos="fade-up">
          <h2 className="text-white text-4xl lg:text-5xl font-bold mb-8 drop-shadow-lg">
            Future Goals
          </h2>
          <p className="text-white text-xl lg:text-2xl leading-relaxed drop-shadow-md">
            Scale up production to meet India's renewable targets and continue R&D investments for enhanced turbine efficiency.
          </p>
        </div>
      </div>
    </section>
  );
}
