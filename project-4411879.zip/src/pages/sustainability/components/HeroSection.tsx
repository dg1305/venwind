export default function HeroSection() {
  return (
    <section 
      className="relative h-[60vh] lg:h-[70vh] w-full overflow-hidden bg-cover bg-center"
      style={{
        backgroundImage: 'url(https://readdy.ai/api/search-image?query=Modern%20wind%20turbines%20in%20a%20vast%20green%20field%20under%20blue%20sky%20with%20white%20clouds%2C%20renewable%20energy%20farm%20landscape%2C%20sustainable%20power%20generation%2C%20clean%20technology%20infrastructure%2C%20aerial%20perspective%20showing%20multiple%20wind%20turbines%20across%20rolling%20hills%2C%20bright%20natural%20lighting%2C%20professional%20photography%20style&width=1920&height=800&seq=sustainability-hero-bg&orientation=landscape)'
      }}
    >
      <div className="absolute inset-0 bg-black/40"></div>
      <div className="relative z-10 h-full flex items-center justify-center">
        <div className="text-center px-6">
          <h1 className="text-white text-5xl lg:text-6xl font-bold" data-aos="fade-up">
            Sustainability
          </h1>
        </div>
      </div>
    </section>
  );
}
