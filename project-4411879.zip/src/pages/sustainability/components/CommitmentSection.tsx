export default function CommitmentSection() {
  const commitments = [
    {
      title: 'Carbon Footprint Reduction',
      description: 'Advanced wind technology minimizes emissions.',
      image: 'https://venwindrefex.com/wp-content/uploads/2025/01/sustainibility-img01.jpg'
    },
    {
      title: 'Cost Efficiency',
      description: 'Low lifecycle costs through innovative engineering.',
      image: 'https://venwindrefex.com/wp-content/uploads/2025/01/sustainibility-img02.jpg'
    },
    {
      title: 'Community Impact',
      description: 'Job creation and access to renewable energy for local communities.',
      image: 'https://venwindrefex.com/wp-content/uploads/2025/01/sustainibility-img03.jpg'
    }
  ];

  return (
    <section className="bg-white py-20 lg:py-24">
      <div className="max-w-7xl mx-auto px-6 lg:px-16">
        <h2 
          className="text-gray-900 text-4xl lg:text-5xl font-bold text-center mb-16"
          data-aos="fade-up"
        >
          Our Commitment
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {commitments.map((item, index) => (
            <div 
              key={index}
              className="text-center group cursor-pointer"
              data-aos="fade-up"
              data-aos-delay={index * 150}
            >
              <div className="mb-6 overflow-hidden rounded-lg shadow-lg">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-auto object-cover transition-transform duration-700 ease-in-out group-hover:scale-110"
                />
              </div>
              <h3 className="text-gray-900 text-xl lg:text-2xl font-bold mb-4">
                {item.title}
              </h3>
              <p className="text-gray-700 text-base leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
