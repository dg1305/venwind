
export default function MapSection() {
  return (
    <section className="w-full">
      <iframe
        src="https://maps.google.com/maps?t=m&output=embed&iwloc=near&z=17&q=Sixth+Floor%2C+Refex+Towers%2C+Sterling+Road+Signal%2C++313%2C+Valluvar+Kottam+High+Road%2C++Nungambakkam%2C+Chennai+%E2%80%93+600034%2C+Tamil+Nadu"
        className="w-full h-[400px]"
        style={{ border: 0 }}
        allowFullScreen
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
        title="Venwind Refex Office Location"
      />
    </section>
  );
}
