import { useState } from 'react';

export default function BenefitsSection() {
  const [openIndex, setOpenIndex] = useState<number>(-1);

  const benefits = [
    {
      title: 'Improved Power Generation',
      content: (
        <ul className="list-disc pl-5 space-y-2">
          <li>Higher wind energy utilization and adaptability</li>
          <li>Large rotor diameter and higher hub height for its class</li>
          <li>Lesser BOP and O&M costs due to larger size resulting in improved LCOE</li>
        </ul>
      ),
    },
    {
      title: 'Technology optimization',
      content: 'Optimized design strategy to get advantage of permanent magnet generator at medium speed',
    },
    {
      title: 'Lesser maintenance',
      content: 'Medium speed Gearbox (MSPM) design ensures minimum maintenance and high reliability',
    },
    {
      title: 'Reliability',
      content: 'German technology with more than 2GW installations of the 5.3MW WTG platform worldwide by Vensys technology partners',
    },
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left Image */}
          <div data-aos="fade-right">
            <img
              src="https://readdy.ai/api/search-image?query=Multiple%20white%20wind%20turbines%20in%20vast%20green%20field%20installation%2C%20wind%20farm%20renewable%20energy%20facility%2C%20professional%20industrial%20photography%20showing%20turbine%20array%2C%20clear%20blue%20sky%2C%20sustainable%20clean%20power%20generation%20infrastructure%2C%20detailed%20engineering%20equipment&width=800&height=900&seq=benefits-001&orientation=portrait"
              alt="Wind Turbine Benefits"
              className="w-full h-auto rounded-lg shadow-lg object-cover object-top"
            />
          </div>

          {/* Right Content */}
          <div data-aos="fade-left">
            <h2 className="text-gray-900 text-4xl lg:text-5xl font-bold mb-8">
              Other Benefits
            </h2>
            
            <div className="space-y-4">
              {benefits.map((benefit, index) => (
                <div key={index} className="border-b border-gray-200">
                  <button
                    onClick={() => setOpenIndex(openIndex === index ? -1 : index)}
                    className="w-full flex items-center justify-between py-4 text-left transition-colors cursor-pointer"
                    style={{ color: openIndex === index ? '#8DC63F' : '#111827' }}
                    onMouseEnter={(e) => e.currentTarget.style.color = '#8DC63F'}
                    onMouseLeave={(e) => e.currentTarget.style.color = openIndex === index ? '#8DC63F' : '#111827'}
                  >
                    <span className="text-lg font-semibold pr-4">
                      {benefit.title}
                    </span>
                    <i className={`${openIndex === index ? 'ri-subtract-line' : 'ri-add-line'} text-2xl text-gray-600 flex-shrink-0`}></i>
                  </button>
                  <div
                    className={`overflow-hidden transition-all duration-300 ${
                      openIndex === index ? 'max-h-96 pb-4' : 'max-h-0'
                    }`}
                  >
                    <div className="text-gray-700 text-base leading-relaxed">
                      {benefit.content}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
