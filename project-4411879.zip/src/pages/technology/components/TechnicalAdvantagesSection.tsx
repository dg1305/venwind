import { useState } from 'react';

export default function TechnicalAdvantagesSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const advantages = [
    {
      title: 'Variable-Speed Variable-Pitch Control',
      content: 'Advanced control system that optimizes turbine performance by adjusting both rotor speed and blade pitch angle in real-time, maximizing energy capture across varying wind conditions while reducing mechanical stress and extending component lifetime.'
    },
    {
      title: 'Permanent Magnet, Medium Speed Drive-Train Technology',
      content: 'Innovative drivetrain combining a medium-speed gearbox with a permanent magnet generator, eliminating the need for external excitation, reducing losses, and improving overall system efficiency while minimizing maintenance requirements.'
    },
    {
      title: 'Adaptive Active Yaw System',
      content: 'Intelligent yaw control system that continuously adjusts the nacelle orientation to optimize wind capture and reduce loads, using advanced algorithms and real-time wind data to maximize energy production and minimize wear on components.'
    },
    {
      title: 'Full-Power Converter',
      content: 'State-of-the-art power electronics that convert 100% of generated power, providing superior grid support capabilities, excellent power quality, and enabling advanced grid services such as voltage and frequency regulation.'
    },
    {
      title: 'Comprehensive Load and Strength Calculation',
      content: 'Rigorous engineering analysis using advanced simulation tools to ensure structural integrity and optimal performance under all operating conditions, including extreme weather events and grid disturbances.'
    },
    {
      title: 'Capacitance Detection Technology:',
      content: 'Advanced monitoring system that detects and prevents potential electrical issues before they occur, enhancing safety and reliability while reducing unplanned downtime and maintenance costs.'
    },
    {
      title: 'Modular Structural Design',
      content: 'Flexible architecture that allows for easy upgrades, modifications, and maintenance, reducing installation time and costs while enabling future technology integration and capacity enhancements.'
    },
    {
      title: 'Quality Control and Factory Inspection System',
      content: 'Comprehensive quality assurance program with rigorous testing and inspection protocols at every stage of manufacturing, ensuring the highest standards of reliability and performance for every turbine.'
    },
    {
      title: 'Monitoring Systems',
      content: 'Advanced SCADA and condition monitoring systems that provide real-time performance data, predictive maintenance alerts, and comprehensive analytics to optimize operations and maximize uptime across the entire wind farm.'
    },
  ];

  const toggleAccordion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-16">
        <h2 className="text-gray-900 text-4xl lg:text-5xl font-bold text-center mb-16" data-aos="fade-up">
          Technical Advantages
        </h2>
        
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Left Image */}
          <div className="hidden lg:block" data-aos="fade-right">
            <img 
              src="https://static.readdy.ai/image/d0ead66ce635a168f1e83b108be94826/c2eebabd6ae5a37d680f0e2d25f25aac.png"
              alt="Wind turbine technical advantages"
              className="w-3/4 h-auto rounded-lg object-cover object-top mx-auto"
            />
          </div>
          
          {/* Right Accordion */}
          <div className="space-y-4">
            {advantages.map((advantage, index) => (
              <div 
                key={index}
                className="bg-white border border-gray-200 overflow-hidden"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <button
                  onClick={() => toggleAccordion(index)}
                  className="w-full px-8 py-6 flex items-center justify-between hover:bg-gray-50 transition-colors cursor-pointer"
                >
                  <h3 className="text-gray-900 text-xl font-bold text-left whitespace-nowrap">{advantage.title}</h3>
                  <div className="w-8 h-8 flex items-center justify-center flex-shrink-0 ml-4">
                    <i className={`ri-${openIndex === index ? 'subtract' : 'add'}-line text-2xl transition-transform duration-300`} style={{ color: '#8DC63F' }}></i>
                  </div>
                </button>
                
                <div 
                  className={`overflow-hidden transition-all duration-300 ${
                    openIndex === index ? 'max-h-96' : 'max-h-0'
                  }`}
                >
                  <div className="px-8 pb-6">
                    <p className="text-gray-700 text-base leading-relaxed">
                      {advantage.content}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
