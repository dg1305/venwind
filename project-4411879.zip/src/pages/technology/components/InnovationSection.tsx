
export default function InnovationSection() {
  const features = [
    {
      icon: 'ri-settings-3-line',
      title: 'High Reliability',
      description: 'Based on mature WTG design platform',
    },
    {
      icon: 'ri-flashlight-line',
      title: 'High Performance',
      description: 'The turbine specific and site-level self-learning optimization algorithm, enables autonomous optimization of power generation performance',
    },
    {
      icon: 'ri-stack-line',
      title: 'High Scalability',
      description: 'Multiple optional configurations and software & hardware interfaces based on platform and module development',
    },
    {
      icon: 'ri-plug-line',
      title: 'Grid Friendly Connection',
      description: 'ZVRT and primary frequency modulation realizes outstanding grid code compliance even in case of a weak grid, hence voltage ride through (LVRT & HVRT)',
    },
    {
      icon: 'ri-tools-line',
      title: 'High Adaptability',
      description: 'Load shedding technology based on advanced sensing for harnessing maximum performance potential',
    },
    {
      icon: 'ri-shield-check-line',
      title: 'High Safety',
      description: 'Reliable precaution strategies for extreme weather can be delivered based on the exclusively accurate weather data',
    },
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-16">
        <h2 className="text-gray-900 text-4xl lg:text-5xl font-bold text-center mb-16" data-aos="fade-up">
          Salient features
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="text-center"
              data-aos="fade-up"
              data-aos-delay={index * 100}
            >
              <div className="w-20 h-20 mx-auto mb-6 rounded-full flex items-center justify-center" style={{ backgroundColor: '#8DC63F20' }}>
                <i className={`${feature.icon} text-4xl`} style={{ color: '#8DC63F' }}></i>
              </div>
              <h3 className="text-gray-900 text-xl font-bold mb-4">{feature.title}</h3>
              <p className="text-gray-700 text-base leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
