export default function HeroSection() {
  return (
    <>
      {/* Header Spacer */}
      <div className="h-24 bg-white"></div>
      
      {/* Hero Section */}
      <section className="relative h-96 flex items-center justify-center">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url(https://static.readdy.ai/image/d0ead66ce635a168f1e83b108be94826/4b74db04643c7883ecfe23fb9eba78d5.png)'
          }}
        >
          <div className="absolute inset-0 bg-black/40"></div>
        </div>
        
        <div className="relative z-10 text-center">
          <h1 className="text-white text-5xl lg:text-6xl font-bold">Technology</h1>
        </div>
      </section>
    </>
  );
}
