export default function ComparisonSection() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-16">
        <h2 className="text-gray-900 text-4xl lg:text-5xl font-bold text-center mb-16" data-aos="fade-up">
          Technology Comparison
        </h2>
        
        <div className="overflow-x-auto" data-aos="fade-up" data-aos-delay="100">
          <table className="w-full bg-white shadow-sm">
            <thead>
              <tr className="bg-gray-900 text-white">
                <th className="px-6 py-4 text-left font-bold">Aspect</th>
                <th className="px-6 py-4 text-left font-bold">Vensys GWH182-5.3 PMG Hybrid technology</th>
                <th className="px-6 py-4 text-left font-bold">Gearbox wind turbines DFIG</th>
              </tr>
            </thead>
            <tbody className="text-gray-700">
              <tr className="border-b border-gray-200">
                <td className="px-6 py-4 font-semibold">Design concept</td>
                <td className="px-6 py-4">Optimized design strategy to get advantage of permanent magnet generator at medium speed</td>
                <td className="px-6 py-4">High speed generator and moving parts</td>
              </tr>
              <tr className="border-b border-gray-200 bg-gray-50">
                <td className="px-6 py-4 font-semibold">Reliability</td>
                <td className="px-6 py-4">Higher reliability due to medium speed</td>
                <td className="px-6 py-4">More prone to mechanical failures due to high speed</td>
              </tr>
              <tr className="border-b border-gray-200">
                <td className="px-6 py-4 font-semibold">Maintenance</td>
                <td className="px-6 py-4">Lower maintenance costs</td>
                <td className="px-6 py-4">Higher maintenance costs and regular up keep for high-speed gearbox and other components</td>
              </tr>
              <tr className="border-b border-gray-200 bg-gray-50">
                <td className="px-6 py-4 font-semibold">Efficiency</td>
                <td className="px-6 py-4">Higher efficiency due to lower losses</td>
                <td className="px-6 py-4">Energy losses due to high temperature operations</td>
              </tr>
              <tr className="border-b border-gray-200">
                <td className="px-6 py-4 font-semibold">Noise Level</td>
                <td className="px-6 py-4">Quieter operations</td>
                <td className="px-6 py-4">Noisier due to high speed operation</td>
              </tr>
              <tr className="border-b border-gray-200 bg-gray-50">
                <td className="px-6 py-4 font-semibold">Grid Friendly</td>
                <td className="px-6 py-4">Active & Reactive power control and LVRT & HVRT</td>
                <td className="px-6 py-4">Challenges of maintaining power factor and LVRT & HVRT</td>
              </tr>
              <tr>
                <td className="px-6 py-4 font-semibold">Cost</td>
                <td className="px-6 py-4">Lower LCOE during project lifetime</td>
                <td className="px-6 py-4">Higher LCOE due to higher operational expenses and lower turbine efficiency</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
