import { useState } from 'react';

export default function AdvantagesSection() {
  const [openIndex, setOpenIndex] = useState<number>(-1);

  const advantages = [
    {
      title: 'Higher Wind Energy Utilization',
      content: 'Permanent magnet medium speed technology',
    },
    {
      title: 'Larger Rotor Diameter and Higher Hub Heights in its Class',
      content: 'Captures more wind energy, higher tip speed ratio',
    },
    {
      title: 'Flexible Modular Design',
      content: 'Supports enhancement to higher capacity and higher rotor diameter',
    },
    {
      title: 'Supports application scenarios such as energy storage and distributed wind power',
      content: 'Designed to operate at higher capacities (4.8MW and above)',
    },
    {
      title: 'Grid Connection',
      content: (
        <ul className="list-disc pl-5 space-y-2">
          <li>Operates at a constant power factor, independent of grid voltage</li>
          <li>No need for external grid excitation</li>
        </ul>
      ),
    },
    {
      title: 'Low cut-in wind speed',
      content: 'Cut-in wind speed 2.5m/s',
    },
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div data-aos="fade-right">
            <h2 className="text-gray-900 text-4xl lg:text-5xl font-bold mb-8">
              Advantages over Competitors
            </h2>
            
            <div className="space-y-4">
              {advantages.map((advantage, index) => (
                <div key={index} className="border-b border-gray-200">
                  <button
                    onClick={() => setOpenIndex(openIndex === index ? -1 : index)}
                    className="w-full flex items-center justify-between py-4 text-left transition-colors cursor-pointer"
                    style={{ color: openIndex === index ? '#8DC63F' : '#111827' }}
                    onMouseEnter={(e) => e.currentTarget.style.color = '#8DC63F'}
                    onMouseLeave={(e) => e.currentTarget.style.color = openIndex === index ? '#8DC63F' : '#111827'}
                  >
                    <span className="text-lg font-semibold pr-4">
                      {advantage.title}
                    </span>
                    <i className={`${openIndex === index ? 'ri-subtract-line' : 'ri-add-line'} text-2xl text-gray-600 flex-shrink-0`}></i>
                  </button>
                  <div
                    className={`overflow-hidden transition-all duration-300 ${
                      openIndex === index ? 'max-h-96 pb-4' : 'max-h-0'
                    }`}
                  >
                    <div className="text-gray-700 text-base leading-relaxed">
                      {advantage.content}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Image */}
          <div data-aos="fade-left" className="flex justify-center">
            <div className="w-3/4">
              <img
                src="https://readdy.ai/api/search-image?query=modern%20wind%20turbine%20tower%20with%20advanced%20technology%20components%20and%20engineering%20details%2C%20clean%20industrial%20setting%20with%20blue%20sky%20background%2C%20professional%20technical%20photography%20showing%20innovation%20in%20renewable%20energy%20manufacturing&width=600&height=800&seq=tech-adv-img-001&orientation=portrait"
                alt="Wind Turbine Advantages"
                className="w-full h-auto rounded-lg shadow-lg object-cover object-top"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
