
export default function IntroSection() {
  return (
    <section className="py-0 bg-white">
      <div className="flex flex-col lg:flex-row">
        {/* Left Image */}
        <div className="w-full lg:w-1/2">
          <img
            src="https://venwindrefex.com/wp-content/uploads/2025/01/gallery-img03.jpg"
            alt="Wind Turbine Technology"
            className="w-full h-full object-cover"
            data-aos="fade-right"
          />
        </div>

        {/* Right Content */}
        <div className="w-full lg:w-1/2 bg-gray-50 relative flex items-center">
          <div className="max-w-2xl mx-auto px-8 lg:px-16 py-16 lg:py-20">
            <div className="bg-white p-8 lg:p-12 shadow-sm">
              <span className="text-sm font-semibold uppercase tracking-wider mb-4 block" style={{ color: '#8DC63F' }} data-aos="fade-up">
                Overview
              </span>
              <h2 className="text-gray-900 text-3xl lg:text-4xl font-bold mb-6" data-aos="fade-up" data-aos-delay="100">
                Advanced Technology for Superior Performance
              </h2>
              <ul className="space-y-4 text-gray-700 text-base leading-relaxed" data-aos="fade-up" data-aos-delay="200">
                <li className="flex items-start">
                  <i className="ri-checkbox-circle-fill text-xl mr-3 mt-1" style={{ color: '#8DC63F' }}></i>
                  <span>Permanent magnet synchronous generator and full-scale power converter enables rapid dispatch response, more active power/frequency, reactive power/voltage control, and smoother fault voltage ride-through</span>
                </li>
                <li className="flex items-start">
                  <i className="ri-checkbox-circle-fill text-xl mr-3 mt-1" style={{ color: '#8DC63F' }}></i>
                  <span>Reduced maintenance as a result of elimination of high-speed couplings and slip ring carbon brushes, cutting fault rates by 70% compared to DFIG wind turbines</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
