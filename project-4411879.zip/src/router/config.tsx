import type { RouteObject } from "react-router-dom";
import { lazy } from "react";
import NotFound from "../pages/NotFound";
import Home from "../pages/home/page";
import AboutUs from "../pages/about/page";
import Products from "../pages/products/page";
import Technology from "../pages/technology/page";
import Sustainability from "../pages/sustainability/page";
import Careers from "../pages/careers/page";
import Contact from "../pages/contact/page";
import AdminPage from "../pages/admin/page";
import LoginPage from "../pages/login/page";

const routes: RouteObject[] = [
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/about-us",
    element: <AboutUs />,
  },
  {
    path: "/products",
    element: <Products />,
  },
  {
    path: "/technology",
    element: <Technology />,
  },
  {
    path: "/sustainability",
    element: <Sustainability />,
  },
  {
    path: "/careers",
    element: <Careers />,
  },
  {
    path: "/contact",
    element: <Contact />,
  },
  {
    path: "/login",
    element: <LoginPage />,
  },
  {
    path: "/admin",
    element: <AdminPage />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
];

export default routes;
